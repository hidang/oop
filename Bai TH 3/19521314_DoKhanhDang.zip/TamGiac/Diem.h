#pragma once

class Diem
{
private:
    float x, y;

public:
    void Nhap();
    void Xuat();

    void TinhTien(double aa, double bb);
    void Quay(double rad);
    void ThuPhong(double k);
};
